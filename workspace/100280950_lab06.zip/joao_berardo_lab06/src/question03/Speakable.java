package question03;

/**
 * Interface to help different animals speak
 * 
 * @author Joao Berardo
 * @since 1.0, July, 01 2017 
 *
 */
public interface Speakable {
	public void speak();
}