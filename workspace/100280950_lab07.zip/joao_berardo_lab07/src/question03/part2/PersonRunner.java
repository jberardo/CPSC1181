package question03.part2;

/**
 *
 * 
 * @author Joao Berardo
 * @since 1.0, July, 09 2017
 */
public class PersonRunner
{
	/**
	 * Main method
	 * @param args not used
	 */
	public static void main(String[] args)
	{
		//
		Person aperson = new Person("John Doe", 36);
		
		//
		aperson.tellAll();
		
		//
		aperson.rememberAnEvent("I was born in 1980.");
		aperson.rememberAnEvent("I finished school in 2003.");
		aperson.tellAll();
		
		// 
		aperson.amnesia();
		aperson.tellAll();

		// 
		aperson.rememberAnEvent("Test mem");
		aperson.tellAll();
	}
}