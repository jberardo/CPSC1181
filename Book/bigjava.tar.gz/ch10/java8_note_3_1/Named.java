public interface Named
{
   default String name() { return "(NONE)"; }
}
